"""
TimeSeriesDataset variant for QuitoBench runs (installed as quito/strided.py and imported from
quito/models/__init__.py, so that quito-cli finds it). Select it per dataset in a config:
`ds_cls: StridedTimeSeriesDataset`, `ds_kwargs: {stride: k}`.

- Windows: with stride 1 it enumerates exactly the windows of TimeSeriesDataset (same split,
  scaler and order); with stride k it keeps window j = 0, k, 2k, ... of each series (the first
  test origin is always kept), so every model scored with the same config sees the same windows.
- Speed only: quito's evaluate.py puts the dataset in Ray's object store and deep-copies it once
  per series; pickling here leaves out the raw dataframe `_df` (the driver has read the series
  ids from it before; select_user_data and __getitem__ never use it). Results are unchanged.
"""
from quito.datasets import DATASET_MAPPING, TimeSeriesDataset
from quito.utils.common import register_to_mapping


@register_to_mapping(DATASET_MAPPING)
class StridedTimeSeriesDataset(TimeSeriesDataset):
    def __init__(self, *args, stride: int = 1, **kwargs):
        if int(stride) < 1:
            raise ValueError("stride must be a positive integer")
        self.stride = int(stride)
        super().__init__(*args, **kwargs)

    def _per_series(self) -> int:
        dense = self.data.shape[1] - self.seq_len - self.forecast_horizon + 1
        return max(0, -(-dense // self.stride))

    def __len__(self) -> int:
        # TimeSeriesDataset counts windows x data.shape[0] in both modes (S: data is (N*C, L, 1))
        return self._per_series() * self.data.shape[0]

    def _fetch_sample_idx(self, idx):
        per_series = self._per_series()
        return idx // per_series, (idx % per_series) * self.stride

    def __getstate__(self):
        state = self.__dict__.copy()
        state["_df"] = None
        return state
